// Copyright (C) 2002 IAIK
// http://jce.iaik.at
//
// Copyright (C) 2003 - 2016 Stiftung Secure Information and
//                           Communication Technologies SIC
// http://www.sic.st
//
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
// 1. Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
// 2. Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
// OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
// OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
// SUCH DAMAGE.

package demo.math.ec;

import iaik.security.ec.common.SecurityStrength;
import iaik.security.ec.math.curve.AtePairingOverBarretoNaehrigCurveFactory;
import iaik.security.ec.math.curve.ECPoint;
import iaik.security.ec.math.curve.EllipticCurve;
import iaik.security.ec.math.curve.Pairing;
import iaik.security.ec.math.curve.PairingTypes;
import iaik.security.ec.math.field.GenericField;
import iaik.security.ec.math.field.GenericFieldElement;

import java.math.BigInteger;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

import demo.ECCelerateDemo;

/**
 * Demonstrates how the pairing implementation can be used.
 *
 * @author Sebastian Ramacher
 * @author Christian Hanser
 */
public final class PairingDemo implements ECCelerateDemo {

  /**
   * Contains some basic pairing examples, including the usage of Type-2 and
   * Type-3 curves and hashing onto curves (onto curve 1 for Type-2 and onto
   * curve 1 and 2 for Type-3 pairings). Note that hashing to curve 2 is not
   * possible in case of Type-2 pairings.
   *
   * @param size
   *          the size of the curve to be used
   * @throws NoSuchAlgorithmException
   */
  private void run(final int size) throws NoSuchAlgorithmException {
    // create Type-3 pairing
    final Pairing pairing3 = AtePairingOverBarretoNaehrigCurveFactory.getPairing(
        PairingTypes.TYPE_3, size);

    EllipticCurve curve1 = pairing3.getGroup1();
    EllipticCurve curve2 = pairing3.getGroup2();
    GenericField target = pairing3.getTargetGroup();

    System.out.println("---");
    System.out.println("Type-3 pairing:");
    System.out.println("G1: " + curve1);
    System.out.println("G2: " + curve2);
    System.out.println("target group: " + target);

    // obtain generators of the two curves
    ECPoint p = curve1.getGenerator();
    ECPoint q = curve2.getGenerator();

    System.out.println("---");
    System.out.println("p = " + p);
    System.out.println("q = " + q);

    // compute pairing of p and q
    GenericFieldElement t = pairing3.pair(p, q);

    System.out.println("---");
    System.out.println("e(p,q) = " + t);

    // get scalars
    final SecureRandom random = SecurityStrength.getSecureRandom(SecurityStrength
        .getSecurityStrength(curve1.getField().getFieldSize()));
    BigInteger k1 = new BigInteger(size - 1, random);
    BigInteger k2 = new BigInteger(size - 1, random);

    // hash onto curve 1
    final ECPoint p2 = curve1.hashToPoint(iaik.utils.Util.toByteArray("Test hashing onto curve 1"));

    // multiply points from curve 2 with scalars
    ECPoint r = q.clone().multiplyPoint(k1);
    ECPoint s = q.clone().multiplyPoint(k2);

    // compute pairing of p2 and r, and p2 and s
    GenericFieldElement[] ts = pairing3.pair(p2, new ECPoint[] { r, s });

    System.out.println("e(p2,r) = " + ts[0]);
    System.out.println("e(p2,s) = " + ts[1]);

    // hash onto curve 2
    final ECPoint q2 = curve2.hashToPoint(iaik.utils.Util.toByteArray("Test hashing onto curve 2"));

    // multiply points from curve 1 with scalars
    r = p.clone().multiplyPoint(k1);
    s = p.clone().multiplyPoint(k2);

    // compute pairing of q2 and r, and q2 and s
    ts = pairing3.pair(new ECPoint[] { r, s }, q2);

    System.out.println("e(r,q2) = " + ts[0]);
    System.out.println("e(s,q2) = " + ts[1]);

    System.out.println("---");

    // create Type-2 pairing
    final Pairing pairing2 = AtePairingOverBarretoNaehrigCurveFactory.getPairing(
        PairingTypes.TYPE_2, size);

    curve1 = pairing2.getGroup1();
    curve2 = pairing2.getGroup2();
    target = pairing2.getTargetGroup();

    System.out.println("Type-2 pairing:");
    System.out.println("G1: " + curve1);
    System.out.println("G2: " + curve2);
    System.out.println("target group: " + target);

    // obtain generators of the two curves
    p = curve1.getGenerator();
    q = curve2.getGenerator();

    System.out.println("---");
    System.out.println("p = " + p);
    System.out.println("q = " + q);

    // compute pairing of p and q
    t = pairing2.pair(p, q);

    System.out.println("---");
    System.out.println("e(p,q) = " + t);

    // apply the isomporphism from curve 2 to curve 1 (result is the same as in
    // e(p,q))
    t = pairing2.pair(pairing2.applyIsomorphism(q), q);
    System.out.println("e(Psi(q),q) = " + t);

    // get scalars
    k1 = new BigInteger(size - 1, random);
    k2 = new BigInteger(size - 1, random);

    // hash onto curve 1
    final ECPoint p3 = curve1.hashToPoint(iaik.utils.Util.toByteArray("Test hashing onto curve 1"));

    // multiply points from curve 2 with scalars
    r = q.clone().multiplyPoint(k1);
    s = q.clone().multiplyPoint(k2);

    // compute pairing of p3 and r, and p3 and s
    ts = pairing2.pair(p3, new ECPoint[] { r, s });

    System.out.println("e(p3,r) = " + ts[0]);
    System.out.println("e(p3,s) = " + ts[1]);
  }

  @Override
  public boolean run() {
    System.out.println("IAIK Pairing Demo");
    System.out.println();

    try {
      run(160);
      run(256);
    } catch (final Exception e) {
      System.out.println("Error: " + e.getMessage());

      return false;
    }

    return true;
  }

  /**
   * The main method.
   *
   * @param args
   *          will be ignored
   */
  public static void main(final String[] args) {
    final PairingDemo demo = new PairingDemo();

    // return exit status 0, if no error occurred or 1 otherwise
    final int result = demo.run() ? 0 : 1;
    // wait for user input
    iaik.utils.Util.waitKey();

    System.exit(result);
  }

}
