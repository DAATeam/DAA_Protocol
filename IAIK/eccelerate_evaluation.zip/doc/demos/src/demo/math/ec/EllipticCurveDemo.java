// Copyright (C) 2002 IAIK
// http://jce.iaik.at
//
// Copyright (C) 2003 - 2016 Stiftung Secure Information and
//                           Communication Technologies SIC
// http://www.sic.st
//
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
// 1. Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
// 2. Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
// OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
// OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
// SUCH DAMAGE.

package demo.math.ec;

import iaik.security.ec.errorhandling.InvalidCurveException;
import iaik.security.ec.math.curve.BinaryWeierstrassCurveFactory;
import iaik.security.ec.math.curve.ECPoint;
import iaik.security.ec.math.curve.EllipticCurve;
import iaik.security.ec.math.field.BinaryField;
import iaik.security.ec.math.field.BinaryFieldByBitLengthFactory;
import iaik.security.ec.math.field.Field;
import iaik.security.ec.math.field.FieldElement;

import java.math.BigInteger;
import java.util.Random;

import demo.ECCelerateDemo;

/**
 * Demonstrates how the mathematical EC and finite field implementations can be
 * used to perform computations apart from elliptic curve protocols.
 *
 * @author Christian Hanser
 */
public final class EllipticCurveDemo implements ECCelerateDemo {

  /**
   * Contains some basic EC arithmetic samples.
   *
   * @param size
   *          the size of the curve to be used
   */
  private void run(final int size) throws InvalidCurveException {
    final BinaryField field = BinaryFieldByBitLengthFactory.getField(size);
    final Random random = new Random();

    final EllipticCurve curve = BinaryWeierstrassCurveFactory.getCurve(field, BigInteger.ONE,
        BigInteger.ONE);

    System.out.println("---");
    System.out.println("Using curve: ");
    System.out.println(curve);
    System.out.println();

    // get two points on the curve
    final ECPoint p = getPoint(curve, random);
    final ECPoint q = getPoint(curve, random);

    // adds q to the value of p
    ECPoint r = p.clone().addPoint(q);

    System.out.println();
    System.out.println("r = p + q:\n " + r);

    // scale the result
    r = r.scalePoint();

    System.out.println();
    System.out.println("Scaled r:\n " + r);

    // negate p
    final ECPoint t = p.clone().negatePoint();
    System.out.println();
    System.out.println("t = -p:\n " + t);

    // get a scalar
    final BigInteger k = new BigInteger(size, random);

    // multiply p with the scalar k
    ECPoint o = p.clone().multiplyPoint(k);

    System.out.println();
    System.out.println("o = k * p: " + o);

    // scale the result
    o = o.scalePoint();

    System.out.println();
    System.out.println("Scaled o: " + o);
    System.out.println();

    // simultaneous point multiplication
    BigInteger[] scalars = new BigInteger[] { new BigInteger(size, random),
        new BigInteger(size, random), new BigInteger(size, random), new BigInteger(size, random) };
    ECPoint[] points = new ECPoint[] { getPoint(curve, random), getPoint(curve, random),
        getPoint(curve, random), getPoint(curve, random) };

    System.out.println();

    for (int i = 0; i < scalars.length; i++) {
      System.out.println("points[" + i + "]: " + points[i]);
      System.out.println("scalars[" + i + "]: " + scalars[i]);
    }

    ECPoint s = curve.multiplySimultaneously(scalars, points);

    System.out.println("scalars[0] * points[0] + ... + scalars[4] * points[4]:\n " + s);
  }

  /**
   * Returns a random point on the given curve.
   *
   * @param curve
   *          the elliptic curve
   * @param random
   *          a PRNG
   */
  private static ECPoint getPoint(final EllipticCurve curve, final Random random) {
    ECPoint p;
    final Field field = (Field) curve.getField();

    do {
      final FieldElement x = field.newElement(new BigInteger(field.getFieldSize() - 1, random));
      p = curve.getPoint(x);
    } while (p == null);

    System.out.println("Created point " + p);

    return p;
  }

  @Override
  public boolean run() {
    System.out.println("IAIK EllipticCurve Demo");
    System.out.println();

    try {
      run(233);
      run(283);
      run(571);
    } catch (final Exception e) {
      System.out.println("Error: " + e.getMessage());

      return false;
    }

    return true;
  }

  /**
   * The main method.
   *
   * @param args
   *          will be ignored
   */
  public static void main(final String[] args) {
    final EllipticCurveDemo demo = new EllipticCurveDemo();

    // return exit status 0, if no error occurred or 1 otherwise
    final int result = demo.run() ? 0 : 1;
    // wait for user input
    iaik.utils.Util.waitKey();

    System.exit(result);
  }

}
