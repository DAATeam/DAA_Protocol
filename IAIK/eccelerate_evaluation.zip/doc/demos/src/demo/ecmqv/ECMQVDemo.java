// Copyright (C) 2002 IAIK
// http://jce.iaik.at
//
// Copyright (C) 2003 - 2016 Stiftung Secure Information and
//                           Communication Technologies SIC
// http://www.sic.st
//
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
// 1. Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
// 2. Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
// OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
// OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
// SUCH DAMAGE.

package demo.ecmqv;

import iaik.asn1.structures.AlgorithmID;
import iaik.security.ec.common.ECParameterSpec;
import iaik.security.ec.common.ECStandardizedParameterFactory;
import iaik.security.ec.common.KDFParameterSpec;
import iaik.security.ec.common.X963KDFParameterSpec;
import iaik.security.ec.ecdh.ECDHParameterSpec;
import iaik.security.ec.provider.ECCelerate;
import iaik.security.provider.IAIK;
import iaik.utils.Util;

import java.security.Key;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

import javax.crypto.KeyAgreement;
import javax.crypto.SecretKey;

import demo.ECCelerateDemo;

/**
 * This demo shows how the IAIK ECCelerate? library can be employed to use the
 * ECMQV key agreement protocol.
 *
 * @author Christian Wagner
 */
public final class ECMQVDemo implements ECCelerateDemo {

  private final SecureRandom random_;

  /**
   * Default constructor.
   *
   * @throws NoSuchAlgorithmException
   *           in case an earlier version of the IAIK provider (prior to 4.0) is
   *           used
   */
  public ECMQVDemo() throws NoSuchAlgorithmException {
    random_ = SecureRandom.getInstance("SHA512PRNG-SP80090", IAIK.getInstance());
  }

  /**
   * Demo code: performs the key agreement using a given ECMQV algorithm
   *
   * @param algorithm
   *          the ECMQV algorithm identifier_
   * @param keyLength
   *          the bitlength of the underlying domain parameters and key
   * @returns true if the shared secrets are equal, false otherwise
   */
  private boolean agreeOnKey(final String algorithm, final int keyLength) {
    return agreeOnKey(algorithm, keyLength, null, null);
  }

  /**
   * Demo code: performs the key agreement using a given ECMQV algorithm
   *
   * @param algorithm
   *          the ECMQV algorithm identifier_
   * @param keyLength
   *          the bitlength of the underlying domain parameters and key
   * @param kdfParams
   *          the parameters for the key derivation function
   * @param cipher
   *          the cipher for which the key material should be derived
   * @returns true if the shared secrets are equal, false otherwise
   */
  private boolean agreeOnKey(final String algorithm, final int keyLength,
      final KDFParameterSpec kdfParams, final String cipher) {
    boolean success;

    try {
      // select the requested curve domain parameters
      final ECParameterSpec params = ECStandardizedParameterFactory
          .getParametersByBitLength(keyLength);
      // obtain an EC key pair generator
      final KeyPairGenerator kpg = KeyPairGenerator.getInstance("EC", ECCelerate.getInstance());
      // use the EC params and the KDF params to generate a set of ECDH params
      final ECDHParameterSpec ecdhParams = new ECDHParameterSpec(params, kdfParams);
      // initialize the key pair generator with the domain parameters
      kpg.initialize(ecdhParams, random_);

      // the key agreement instance of Alice
      final KeyAgreement kA = KeyAgreement.getInstance(algorithm, ECCelerate.getInstance());
      // the key agreement instance of Bob
      final KeyAgreement kB = KeyAgreement.getInstance(algorithm, ECCelerate.getInstance());

      // the key pair of Alice
      final KeyPair kpA = kpg.generateKeyPair();
      // the key pair of Bob
      final KeyPair kpB = kpg.generateKeyPair();

      // initialize Alice's instance with her private key
      // Note: assigning the ECDH params is required, as the private key is not
      // of
      // type ECDH params.
      // Assigning the SecureRandom is optional, if the default random is
      // not a required NIST SP800-90 PRNG, the key agreement generates a
      // sufficient SecureRandom internally instead.
      kA.init(kpA.getPrivate(), ecdhParams, random_);
      // get Alice's ephemeral public key
      // Note: it's crucial that no key is provided here.
      final Key ephemeralPublicKeyA = kA.doPhase(null, false);

      // initialize Bob's instance with his private key and the ECDH params
      // Note: assigning the ECDH params is required, as the private key is not
      // of
      // type ECDH params.
      // Assigning the SecureRandom is optional, if the default random is
      // not a required NIST SP800-90 PRNG, the key agreement generates a
      // sufficient SecureRandom internally instead.
      kB.init(kpB.getPrivate(), ecdhParams, random_);
      // get Bob's ephemeral public key
      // Note: it's crucial that no key is provided here.
      final Key ephemeralPublicKeyB = kB.doPhase(null, false);

      // do the first real phase using Bob's ephemeral public key
      kA.doPhase(ephemeralPublicKeyB, false);
      // derive the secret using Bob's public key
      kA.doPhase(kpB.getPublic(), true);

      // derive the shared secret for Alice
      String sharedSecretAString;

      if (kdfParams == null) {
        // generate a plain shared secret
        final byte[] sharedSecretA = kA.generateSecret();
        sharedSecretAString = Util.toString(sharedSecretA);
      } else {
        // use the KDF
        final SecretKey keyA = kA.generateSecret(cipher);
        sharedSecretAString = keyA.toString();
      }

      System.out.println();
      System.out.println("---");
      System.out.println("Running " + algorithm + " with the following domain parameters:");
      System.out.println(params);
      System.out.println();
      System.out.println("Alice's shared secret is: " + sharedSecretAString);

      // do the first real phase using Alice's ephemeral public key
      kB.doPhase(ephemeralPublicKeyA, false);
      // derive the secret using Alice's public key
      kB.doPhase(kpA.getPublic(), true);

      // derive the shared secret for Bob
      String sharedSecretBString;

      if (kdfParams == null) {
        // generate a plain shared secret
        final byte[] sharedSecretB = kB.generateSecret();
        sharedSecretBString = Util.toString(sharedSecretB);
      } else {
        // use the KDF
        final SecretKey keyB = kB.generateSecret(cipher);
        sharedSecretBString = keyB.toString();
      }

      System.out.println("Bob's shared secret is:   " + sharedSecretBString);

      // are the secrets equal?
      success = sharedSecretAString.equals(sharedSecretBString);
    } catch (final Throwable e) {
      System.out.println("Error occurred: " + e.getMessage());

      return false;
    }

    // print the result
    System.out.println();
    System.out.println("Key agreement successful: " + (success ? "YES" : "NO"));

    return success;
  }

  @Override
  public boolean run() {
    System.out.println("IAIK ECMQV Demo");
    System.out.println();

    boolean overallSuccess = true;

    // using the ECMQV protocol
    // use curve K-163
    overallSuccess &= agreeOnKey("ECMQV", 163);
    // use curveP-192
    overallSuccess &= agreeOnKey("ECMQV", 192);
    // use curve P-224
    overallSuccess &= agreeOnKey("ECMQV", 224);
    // use curve K-233
    overallSuccess &= agreeOnKey("ECMQV", 233);
    // use curve P-256
    overallSuccess &= agreeOnKey("ECMQV", 256);
    // use curve K-283
    overallSuccess &= agreeOnKey("ECMQV", 283);
    // use curve P-384
    overallSuccess &= agreeOnKey("ECMQV", 384);
    // use curve K-409
    overallSuccess &= agreeOnKey("ECMQV", 409);
    // use curve P-521
    overallSuccess &= agreeOnKey("ECMQV", 521);
    // use curve K-571
    overallSuccess &= agreeOnKey("ECMQV", 571);

    // now use the KDF to derive a 128 bit AES key using ECMQV on a 192 bit
    // curve
    KDFParameterSpec kdfParams = new X963KDFParameterSpec(AlgorithmID.sha256, 128);
    overallSuccess &= agreeOnKey("ECMQV", 192, kdfParams, "AES");

    // now use the KDF to derive a 128 bit AES key using ECMQV on a 233 bit
    // curve
    kdfParams = new X963KDFParameterSpec(AlgorithmID.sha256, 128);
    overallSuccess &= agreeOnKey("ECMQV", 233, kdfParams, "AES");

    System.out.println();
    System.out.println("---");
    System.out.println(overallSuccess ? "All operations were SUCCESSFUL"
        : "At least one operation FAILED");

    return overallSuccess;
  }

  /**
   * The main method.
   *
   * @param args
   *          will be ignored
   */
  public static void main(final String[] args) {
    ECMQVDemo demo = null;

    // add the IAIK as well as the ECC provider
    IAIK.addAsProvider();
    ECCelerate.insertProviderAt(2);

    // create a demo instance
    try {
      demo = new ECMQVDemo();

      // return exit status 0, if no error occurred or 1 otherwise
      final int result = demo.run() ? 0 : 1;
      // wait for user input
      iaik.utils.Util.waitKey();

      System.exit(result);
    } catch (final NoSuchAlgorithmException e) {
      System.out
          .println("The IAIK ECCelerate provider can only be used in combination with IAIK provider versions higher than 4.0");

      System.exit(2);
    }
  }
}
