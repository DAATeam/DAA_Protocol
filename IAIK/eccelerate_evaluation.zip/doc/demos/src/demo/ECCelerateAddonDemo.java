// Copyright (C) 2002 IAIK
// http://jce.iaik.at
//
// Copyright (C) 2003 - 2016 Stiftung Secure Information and
//                           Communication Technologies SIC
// http://www.sic.st
//
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
// 1. Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
// 2. Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
// OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
// OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
// SUCH DAMAGE.

package demo;

import iaik.security.ec.provider.ECCelerate;

/**
 * The ECCelerate Addon holds algorithms that greatly improve the performance of
 * the library and enable point compression/decompression. These algorithms,
 * however, are (assumed to be) subject to patent claims. By default ECCelerate
 * uses the uncompressed form to export public keys. If you want to use point
 * compression and decompression (for the import and export of keys and
 * certificates) you will have to download the ECCelerate Addon bundle and put
 * the file iaik_eccelerate_addon.jar into your classpath (see customization
 * section of the Tutorial). Also, in case you want to employ our arithmetical
 * optimizations to gain full performance, you must include
 * iaik_eccelerate_addon.jar into your classpath. This demo tests whether the
 * addon was found, i.e. is part of the classpath.
 *
 * @author Christian Hanser
 */
public final class ECCelerateAddonDemo implements ECCelerateDemo {

  @Override
  public boolean run() {
    final boolean addonAvailable = ECCelerate.isAddonAvailable();

    // also note: you can force the library to enable/disable the addon by
    // invoking:
    // ECCelerate.setAddonEnabled(boolean)

    System.out.println("ECCelerate addon found: " + addonAvailable);

    return true;
  }

  /**
   * The main method.
   *
   * @param args
   *          will be ignored
   */
  public static void main(final String[] args) {
    final ECCelerateAddonDemo demo = new ECCelerateAddonDemo();
    demo.run();

    // wait for user input
    iaik.utils.Util.waitKey();
  }
}
