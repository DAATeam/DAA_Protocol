// Copyright (C) 2002 IAIK
// http://jce.iaik.at
//
// Copyright (C) 2003 - 2016 Stiftung Secure Information and
//                           Communication Technologies SIC
// http://www.sic.st
//
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
// 1. Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
// 2. Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
// OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
// OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
// SUCH DAMAGE.

package demo.ecdsa;

import iaik.pkcs.PKCSException;
import iaik.pkcs.pkcs12.CertificateBag;
import iaik.pkcs.pkcs12.KeyBag;
import iaik.pkcs.pkcs12.PKCS12;
import iaik.x509.X509Certificate;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.KeyPair;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;

/**
 * Demonstrates how to use the IAIK ECCelerate? library with PKCS#12.
 *
 * @author Christian Hanser
 */
public final class PKCS12Demo extends CreateCertificateDemo {

  private static final String TEST_ID = "MyTest ID";
  private static final char[] PASSWORD = "123456".toCharArray();
  private static final String FILENAME = "test.p12";
  private static final byte[] KEY_ID = { 0x01, 0x02, 0x03, 0x04 };

  /**
   * Creates a new instance.
   *
   * @throws NoSuchAlgorithmException
   *           in case an earlier version of the IAIK provider (prior to 4.0) is
   *           used
   */
  public PKCS12Demo() throws NoSuchAlgorithmException {
    super();
  }

  /**
   * Creates a new PKCS12 object for a given certificate and a given key pair.
   *
   * @param cert
   *          the X.509 certificate
   * @param kp
   *          the key pair
   * @return a PKCS12 object
   * @throws PKCSException
   *           if the creation or encryption of the PCKS12 instance failed
   */
  private PKCS12 createPKCS12(final X509Certificate cert, final KeyPair kp) throws PKCSException {
    final X509Certificate[] certs = new X509Certificate[] { cert };
    final KeyBag keyBag = new KeyBag(kp.getPrivate(), TEST_ID, KEY_ID);
    final CertificateBag[] certBags = new CertificateBag[certs.length];

    certBags[0] = new CertificateBag(certs[0]);
    certBags[0].setFriendlyName(TEST_ID);
    certBags[0].setLocalKeyID(KEY_ID);

    final PKCS12 pkcs12 = new PKCS12(keyBag, certBags, false);
    pkcs12.encrypt(PASSWORD);

    return pkcs12;
  }

  /**
   * Runs the demo and employs curve domain parameters of a certain bitlength.
   *
   * @param bitlength
   *          the bitlength of the curve
   */
  private void run(final int bitlength) throws Exception {
    final KeyPair kp = generateKeyPair(bitlength);
    final X509Certificate cert = createCertificate(kp);

    // create a new PKCS12 object
    final PKCS12 testWrite = createPKCS12(cert, kp);
    final File file = new File(FILENAME);

    final OutputStream os = new FileOutputStream(file);
    try {
      testWrite.writeTo(os);
    } finally {
      try {
        os.close();
      } catch (final IOException e) {
        // ignore
      }
    }

    // parse the PKCS#12 object
    System.out.println("Parsing PKCS#12 object...");

    final InputStream is = new FileInputStream(file);
    PKCS12 pkcs12;
    try {
      pkcs12 = new PKCS12(is);
    } finally {
      try {
        is.close();
      } catch (final IOException e) {
        // ignore
      }
    }

    System.out.println("Verifying MAC...");
    // verify the MAC
    if (!pkcs12.verify(PASSWORD)) {
      throw new PKCSException("Verification error!");
    }

    // decrypt the PKCS#12 object
    System.out.println("Decrypting PKCS#12 object...");
    pkcs12.decrypt(PASSWORD);

    // get the private key
    final KeyBag keyBag = pkcs12.getKeyBag();
    final PrivateKey privateKey = keyBag.getPrivateKey();

    System.out.println("The key is an " + privateKey.getAlgorithm() + " key");
    System.out.println();

    // get the certificates
    final CertificateBag[] certBag = pkcs12.getCertificateBags();

    System.out.println("Certificate : ");
    System.out.println(certBag[0].getCertificate());
    System.out.println("DONE!");
  }

  @Override
  public boolean run() {
    System.out.println("IAIK PKCS#12 Demo");
    System.out.println();

    try {
      run(192);
      run(283);
      run(521);
    } catch (final Exception e) {
      System.out.println("Error occurred: " + e.getMessage());

      return false;
    }

    return true;
  }

  /**
   * The main method.
   *
   * @param args
   *          will be ignored
   */
  public static void main(final String[] args) {
    // add the providers
    init();

    PKCS12Demo demo = null;
    try {
      demo = new PKCS12Demo();

      // return exit status 0, if no error occurred or 1 otherwise
      final int result = demo.run() ? 0 : 1;
      // wait for user input
      iaik.utils.Util.waitKey();

      System.exit(result);
    } catch (final NoSuchAlgorithmException e) {
      System.out.println("Error occured: " + e.getMessage());

      System.exit(2);
    }
  }

}
