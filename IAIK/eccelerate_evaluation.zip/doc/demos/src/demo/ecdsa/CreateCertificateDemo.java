// Copyright (C) 2002 IAIK
// http://jce.iaik.at
//
// Copyright (C) 2003 - 2016 Stiftung Secure Information and
//                           Communication Technologies SIC
// http://www.sic.st
//
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
// 1. Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
// 2. Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
// OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
// OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
// SUCH DAMAGE.

package demo.ecdsa;

import iaik.asn1.ObjectID;
import iaik.asn1.structures.AlgorithmID;
import iaik.asn1.structures.Name;
import iaik.x509.X509Certificate;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.util.Calendar;
import java.util.GregorianCalendar;

import demo.ECCelerateDemo;

/**
 * Demonstrates how the IAIK ECCelerate? library can be used to create X.509
 * certificates.
 *
 * @author Christian Hanser
 */
public class CreateCertificateDemo extends AbstractECDSADemo implements ECCelerateDemo {

  private static final String FILENAME = "test.der";

  /**
   * Creates a new instance.
   *
   * @throws NoSuchAlgorithmException
   *           in case an earlier version of the IAIK provider (prior to 4.0) is
   *           used
   */
  public CreateCertificateDemo() throws NoSuchAlgorithmException {
    super();
  }

  /**
   * Creates a simple, self-signed X.509 certificate.
   *
   * @param kp
   *          the key pair used to generate the certificate
   * @return the generated X509Certificate
   */
  X509Certificate createCertificate(final KeyPair kp) throws InvalidKeyException,
      NoSuchAlgorithmException, CertificateException {
    // creating a self signed test certificate
    final Name subject = new Name();
    subject.addRDN(ObjectID.country, "AT");
    subject.addRDN(ObjectID.organization, "TU Graz");
    subject.addRDN(ObjectID.organizationalUnit, "IAIK");
    subject.addRDN(ObjectID.commonName, "IAIK Test Certificate");

    final X509Certificate cert = new X509Certificate();

    cert.setSerialNumber(BigInteger.valueOf(0x1234L));
    cert.setSubjectDN(subject);
    cert.setPublicKey(kp.getPublic());
    cert.setIssuerDN(subject);

    // set the certificate to be valid not before now
    final GregorianCalendar date = new GregorianCalendar();
    cert.setValidNotBefore(date.getTime());

    date.add(Calendar.MONTH, 6);
    cert.setValidNotAfter(date.getTime());

    // add the X.509 extensions
    System.out.println("Signing certificate ...");
    cert.sign(AlgorithmID.ecdsa, kp.getPrivate());

    return cert;
  }

  /**
   * Creates the certificate, writes it to a file and finally reads it from the
   * file in order to verify its validity.
   *
   * @param bitlength
   *          the bitlength of the domain parameters
   * @return true on success, false otherwise
   */
  private boolean writeAndReadCertificate(final int bitlength) {
    System.out.println();
    System.out.println("---");

    try {
      System.out.println("Creating key pair ...");
      final KeyPair kp = generateKeyPair(bitlength);
      X509Certificate cert = createCertificate(kp);

      // write to file
      System.out.println("Writing certificate to file ...");

      final File file = new File(FILENAME);

      // write the certificate to the file
      FileOutputStream fos = null;
      try {
        fos = new FileOutputStream(file);
        cert.writeTo(fos);
      } finally {
        if (fos != null) {
          try {
            fos.close();
          } catch (final IOException e) {
            // ignore
          }
        }
      }

      // read the certificate from the file
      System.out.println("Reading certificate from file ...");
      FileInputStream fis = null;
      try {
        fis = new FileInputStream(file);
        cert = new X509Certificate(fis);

        // verify it
        System.out.println("Validating self signed cert ...");
        cert.verify();
      } finally {
        if (fis != null) {
          try {
            fis.close();
          } catch (final IOException e) {
            // ignore
          }
        }
      }

      return true;
    } catch (final Exception e) {
      System.out.println("Error occurred: " + e.getMessage());

      return false;
    }
  }

  @Override
  public boolean run() {
    boolean overallSuccess = true;

    System.out.println("IAIK CreateCertificate Demo");
    System.out.println();

    // use curve K-163
    overallSuccess &= writeAndReadCertificate(163);
    // use curve P-192
    overallSuccess &= writeAndReadCertificate(192);
    // use curve P-224
    overallSuccess &= writeAndReadCertificate(224);
    // use curve K-233
    overallSuccess &= writeAndReadCertificate(233);
    // use curve P-256
    overallSuccess &= writeAndReadCertificate(256);
    // use curve K-283
    overallSuccess &= writeAndReadCertificate(283);
    // use curve P-384
    overallSuccess &= writeAndReadCertificate(384);
    // use curve K-409
    overallSuccess &= writeAndReadCertificate(409);
    // use curve P-521
    overallSuccess &= writeAndReadCertificate(521);
    // use curve K-571
    overallSuccess &= writeAndReadCertificate(571);

    System.out.println();
    System.out.println("---");
    System.out.println(overallSuccess ? "All operations were SUCCESSFUL"
        : "At least one operation FAILED");

    return overallSuccess;
  }

  /**
   * The main method.
   *
   * @param args
   *          will be ignored
   */
  public static void main(final String[] args) {
    // add the providers
    init();
    CreateCertificateDemo demo = null;

    try {
      demo = new CreateCertificateDemo();

      // return exit status 0, if no error occurred or 1 otherwise
      final int result = demo.run() ? 0 : 1;
      // wait for user input
      iaik.utils.Util.waitKey();

      System.exit(result);
    } catch (final NoSuchAlgorithmException e) {
      System.out
          .println("The IAIK ECCelerate provider can only be used in combination with IAIK provider versions higher than 4.0");

      System.exit(2);
    }
  }

}
