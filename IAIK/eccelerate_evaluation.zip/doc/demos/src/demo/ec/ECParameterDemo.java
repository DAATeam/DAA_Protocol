// Copyright (C) 2002 IAIK
// http://jce.iaik.at
//
// Copyright (C) 2003 - 2016 Stiftung Secure Information and
//                           Communication Technologies SIC
// http://www.sic.st
//
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
// 1. Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
// 2. Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
// OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
// OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
// SUCH DAMAGE.

package demo.ec;

import java.security.spec.ECParameterSpec;

import demo.ECCelerateDemo;
import iaik.security.ec.common.ECStandardizedParameterFactory;

/**
 * This demo shows the possible ways of obtaining curve domain parameters.
 *
 * @author Christian Hanser
 */
public final class ECParameterDemo implements ECCelerateDemo {

  /**
   * Gets the domain parameters for a given standard name.
   *
   * @param name
   *          the standard name
   */
  private void getParameters(final String name) {
    final ECParameterSpec params = ECStandardizedParameterFactory.getParametersByName(name);

    printParams("Obtaining curve parameters for", name, params);
  }

  /**
   * Gets the domain parameters for an object identifier.
   *
   * @param oid
   *          the object identifier
   */
  private void getParametersByOID(final String oid) {
    final ECParameterSpec params = ECStandardizedParameterFactory.getParametersByOID(oid);

    printParams("Obtaining curve parameters for", oid, params);
  }

  /**
   * Gets the default domain parameters for a given curve size.
   *
   * @param bitlength
   *          the curve size in bits
   */
  private void getParameters(final int bitlength) {
    final ECParameterSpec params = ECStandardizedParameterFactory
        .getParametersByBitLength(bitlength);

    printParams("Obtaining curve parameters of bitlength", Integer.toString(bitlength), params);
  }

  /**
   * Helper method for printing the domain parameters.
   *
   * @param caption
   *          the caption
   * @param description
   *          either the name_, the oid_, or the bitlength as {@link String}
   * @param params
   *          the domain parameters
   */
  private void printParams(final String caption, final String description,
      final ECParameterSpec params) {
    System.out.println();
    System.out.println("---");
    System.out.println(caption + " " + description + ":");
    System.out.println();
    System.out.println(params);
  }

  @Override
  public boolean run() {
    System.out.println("IAIK ECParameter demo");
    System.out.println();

    // get the default 163 bit curve, which is K-283
    getParameters(283);
    // get the NIST binary curve B-163
    getParameters("B-283");
    // get the SEC2 prime curve secp256r1, which is the same as NIST P-256
    getParameters("secp256r1");
    // get the SEC2 prime curve secp571r1 by its object identifier
    getParametersByOID("1.3.132.0.35");

    return true;
  }

  /**
   * The main method.
   *
   * @param args
   *          will be ignored
   */
  public static void main(final String[] args) {
    final ECParameterDemo demo = new ECParameterDemo();
    demo.run();

    // wait for user input
    iaik.utils.Util.waitKey();
  }

}
