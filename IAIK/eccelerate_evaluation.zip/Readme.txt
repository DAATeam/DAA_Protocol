=========================================================
IAIK ECCelerate(TM) Elliptic Curve Cryptography (ECC) Library
   Version 3.02, 08.08.2016
=========================================================

This package contains an implementation of the
following elliptic curve algorithms:
- ECDSA : ANSI X9.62-2005 and SEC 1 v2.0 compliant signatures and key encoding.
- ECDSA Plain : compliant with BSI TR 03111 v1.11
- ECDH  : IEEE P1363a
- ECDH with cofactor multiplication : IEEE P1363a
- ECIES : compliant with SEC1 v2.0
- ECMQV : compliant with SEC1 v2.0 (optional)
- Keypair generation compliant with FIPS 186-4
- Optional arithmetic speedups for special prime and binary curves
- Optional point compression
- Asymmetric Type-2 and Type-3 pairings over Barreto-Naehrig curves (ranging from 160-bit to 638-bit curves)

Please have a look at the doc/readme/Readme.html file for a detailed
features list and a short guide on how to use this package.

Java Platform:
Note that this library is for use with Java 1.5 or higher.

Dependencies:
IAIK ECCelerate depends on IAIK JCE (4.0 or higher).

Bindings for other libraries:
This file also contains bindings for the IAIK iSaSiLk and the IAIK CMS libraries.
Include the bin/iaik_eccelerate_ssl.jar and bin/iaik_eccelerate_cms.jar
jars into your classpath, respectively, in order to use them. The class iaik.security.ssl.ECCelerateProvider 
replaces the class iaik.security.ssl.IaikEccProvider and enables the usage of the new IAIK ECCelerate library
in combination with iSaSiLk. The same applies for the IAIK CMS library, where iaik.cms.ecc.ECCelerateProvider 
replaces iaik.cms.ecc.IaikEccProvider.


For further information about IAIK Java Security products,
as well as the most recent version of this package see
http://jce.iaik.at/

Your SIC/IAIK JavaSecurity Team

