Welcome to IAIK-JCE
===================

This package contains an implementation of the
Java Cryptography Architecture, Java Cryptography 
Extensions (JCA, JCE, specified by SUN/ORACLE) and
other cryptographic classes as well as support for
higher level security standards such as PKCS, ASN.1, 
and X.509. 
The current version of this package is available from
http://jce.iaik.tugraz.at/download/.


After the installation has finished use your
favorite browser to view the Readme.html for
further information.


Your SIC/IAIK JavaSecurity Team
