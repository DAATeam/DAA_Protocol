// Copyright (C) 2002 IAIK
// http://jce.iaik.at
//
// Copyright (C) 2003 - 2016 Stiftung Secure Information and
//                           Communication Technologies SIC
// http://www.sic.st
//
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
// 1. Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
// 2. Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
// OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
// OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
// SUCH DAMAGE.

package demo.ecies;

import iaik.asn1.ASN1Object;
import iaik.asn1.structures.AlgorithmID;
import iaik.security.ec.common.ECParameterSpec;
import iaik.security.ec.common.ECStandardizedParameterFactory;
import iaik.security.ec.common.KDFParameterSpec;
import iaik.security.ec.common.X963KDFParameterSpec;
import iaik.security.ec.ecies.ECIESParameterSpec;
import iaik.security.ec.provider.ECCelerate;
import iaik.security.provider.IAIK;
import iaik.utils.Util;

import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Arrays;

import javax.crypto.Cipher;

import demo.ECCelerateDemo;

/**
 * This demo shows how the IAIK ECCelerate? library can be employed to use the
 * Elliptic Curve Integrated Encryption Scheme (ECIES).
 *
 * @author Christian Wagner
 *
 */
public class ECIESDemo implements ECCelerateDemo {

  private final SecureRandom random_;

  /**
   * Default constructor.
   *
   * @throws NoSuchAlgorithmException
   *           in case an earlier version of the IAIK provider (prior to 4.0) is
   *           used
   */
  public ECIESDemo() throws NoSuchAlgorithmException {
    random_ = SecureRandom.getInstance("SHA512PRNG-SP80090", IAIK.getInstance());
  }

  /**
   * Demo code: performs an encryption and a decryption using the ECIES
   * algorithm.
   *
   * @param algorithm
   *          the ECIES algorithm identifier_
   * @param keyLength
   *          the bitlength of the underlying domain parameters and key
   * @param cipherName
   *          the symmetric cipher which should be used in ECIES.
   * @param macName
   *          the MAC which should be used in ECIES.
   * @return true if the decrypted cipher text equals the clear text; false
   *         otherwise
   */
  private boolean encryptDecrypt(final String algorithm, final int keyLength,
      final KDFParameterSpec kdfParams, final String cipherName, final String macName) {

    final String clearText = "This is the message we want to encrypt and then decrypt!";
    boolean success;

    try {
      /* --- SETUP --- */
      // select the requested curve domain parameters
      final ECParameterSpec params = ECStandardizedParameterFactory
          .getParametersByBitLength(keyLength);
      // obtain an EC key pair generator
      final KeyPairGenerator kpg = KeyPairGenerator.getInstance("EC", ECCelerate.getInstance());
      // initialize the key pair generator with the domain parameters
      kpg.initialize(params, random_);
      // generate a key pair
      final KeyPair keyPair = kpg.generateKeyPair();
      // create ECIES parameter with the given parameters
      final ECIESParameterSpec eciesParams = new ECIESParameterSpec(kdfParams, cipherName, macName);
      // instantiate the ECIES cipher
      final Cipher cipher = Cipher.getInstance(algorithm, ECCelerate.getInstance());

      System.out.println();
      System.out.println("---");
      System.out.println("Running ECIES with the following domain parameters:");
      System.out.println(params);
      System.out.println();
      System.out.println("and with the following algorithms:");
      System.out.println("- MAC: "
          + (macName.length() == 0 ? eciesParams.getDefaultMacName() + " (default) " : macName));
      System.out.println("- Symmetric cipher: "
          + (cipherName.length() == 0 ? eciesParams.getDefaultSymmetricCipherName() + " (default) "
              : cipherName));
      System.out.println();
      System.out.println("The clear text is: " + clearText);

      /* --- ENCRYPT --- */
      // initialize the cipher for encryption
      cipher.init(Cipher.ENCRYPT_MODE, keyPair.getPublic(), eciesParams);
      // perform encryption
      cipher.update(clearText.getBytes());
      final byte[] cipherText = cipher.doFinal();
      System.out.println("The encrypted text is: " + Util.toString(cipherText));

      /* --- EN/DECODE parameters to/from ASN1 --- */
      // ECIES parameter as ASN1Object
      final ASN1Object eciesParamsAsASN1 = eciesParams.toASN1Object();
      // decode ASN1Object back to ECIES parameter
      final ECIESParameterSpec eciesParamsFromASN1 = ECIESParameterSpec.decode(eciesParamsAsASN1);

      /* --- DECRYPT --- */
      // initialize the cipher for decryption
      cipher.init(Cipher.DECRYPT_MODE, keyPair.getPrivate(), eciesParamsFromASN1);
      // perform decryption
      cipher.update(cipherText);

      final byte[] encodedClearText = cipher.doFinal();
      System.out.println("The decrypted cipher text is: " + new String(encodedClearText));
      success = Arrays.equals(clearText.getBytes(), encodedClearText);

    } catch (final Throwable e) {
      System.out.println("Error occurred: " + e.getMessage());
      return false;
    }

    System.out.println();
    System.out.println("Encryption and decryption successful: " + (success ? "YES" : "NO"));

    return success;
  }

  @Override
  public boolean run() {
    System.out.println("IAIK ECIES Demo");
    System.out.println();

    boolean overallSuccess = true;

    final KDFParameterSpec kdfParams = new X963KDFParameterSpec(AlgorithmID.sha256, 128);

    // use curve K-163 with default settings for cipher and MAC
    // ("AES128/CBC/PKCS5Padding","HMAC/SHA-1")
    overallSuccess &= encryptDecrypt("ECIES", 163, kdfParams, "", "");
    // use curveP-192
    overallSuccess &= encryptDecrypt("ECIES", 192, kdfParams, "XOR", "HMAC/SHA");
    // use curve P-224
    overallSuccess &= encryptDecrypt("ECIES", 224, kdfParams, "DESede/CBC/PKCS5Padding",
        "HMAC/SHA224");
    // use curve K-233 - (with AES128/CBC/PKCS5Padding)
    overallSuccess &= encryptDecrypt("ECIES", 233, kdfParams, "2.16.840.1.101.3.4.1.2",
        "HmacSHA256");
    // use curve K-283
    overallSuccess &= encryptDecrypt("ECIES", 256, kdfParams, "AES192/CBC/PKCS5Padding",
        "HmacSHA256");
    // use curve P-256 - (with AES192/CBC/PKCS5Padding)
    overallSuccess &= encryptDecrypt("ECIES", 256, kdfParams, "2.16.840.1.101.3.4.1.22",
        "HMAC/SHA384");
    // use curve P-384
    overallSuccess &= encryptDecrypt("ECIES", 384, kdfParams, "AES256/CBC/PKCS5Padding",
        "HMAC/SHA512");
    // use curve K-409 - (with HMAC/SHA-1)
    overallSuccess &= encryptDecrypt("ECIES", 409, kdfParams, "AES128/CTR/NoPadding",
        "1.2.840.113549.2.9");
    // use curve P-521
    overallSuccess &= encryptDecrypt("ECIES", 521, kdfParams, "AES192/CTR/NoPadding", "CMAC/AES256");
    // use curve K-571 - (with HMAC/512)
    overallSuccess &= encryptDecrypt("ECIES", 571, kdfParams, "AES256/CTR/NoPadding",
        "1.2.840.113549.2.11");

    System.out.println();
    System.out.println("---");
    System.out.println(overallSuccess ? "All operations were SUCCESSFUL"
        : "At least one operation FAILED");

    return overallSuccess;
  }

  /**
   * The main method.
   *
   * @param args
   *          will be ignored
   */
  public static void main(final String[] args) {
    ECIESDemo demo = null;

    // add the IAIK as well as the ECC provider
    IAIK.addAsProvider();
    ECCelerate.insertProviderAt(2);

    // create a demo instance
    try {
      demo = new ECIESDemo();

      // return exit status 0, if no error occurred or 1 otherwise
      final int result = demo.run() ? 0 : 1;
      // wait for user input
      iaik.utils.Util.waitKey();

      System.exit(result);
    } catch (final NoSuchAlgorithmException e) {
      System.out
          .println("The IAIK ECCelerate provider can only be used in combination with IAIK provider versions higher than 4.0");

      System.exit(2);
    }
  }

}