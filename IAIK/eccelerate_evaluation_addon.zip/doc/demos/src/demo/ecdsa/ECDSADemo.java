// Copyright (C) 2002 IAIK
// http://jce.iaik.at
//
// Copyright (C) 2003 - 2016 Stiftung Secure Information and
//                           Communication Technologies SIC
// http://www.sic.st
//
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
// 1. Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
// 2. Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
// OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
// OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
// SUCH DAMAGE.

package demo.ecdsa;

import iaik.security.ec.provider.ECCelerate;
import iaik.utils.Util;

import java.security.KeyPair;
import java.security.NoSuchAlgorithmException;
import java.security.Signature;

import demo.ECCelerateDemo;

/**
 * This demo shows how the IAIK ECCelerate? library can be employed to sign
 * and verify data using different ECDSA variants and different domain
 * parameters.
 *
 * @author Christian Hanser
 */
public final class ECDSADemo extends AbstractECDSADemo implements ECCelerateDemo {

  private static final String TO_BE_SIGNED = "Data to be signed";

  /**
   * Default constructor.
   *
   * @throws NoSuchAlgorithmException
   *           in case an earlier version of the IAIK provider (prior to 4.0) is
   *           used
   */
  public ECDSADemo() throws NoSuchAlgorithmException {
    super();
  }

  /**
   * Demo code: signs and verifies the data using ECDSA.
   *
   * @param algorithm
   *          the ECDSA algorithm identifier_
   * @param bitlength
   *          the bitlength of the underlying domain parameters and key
   * @returns true if the created signatures are valid, false otherwise
   */
  private boolean signAndVerify(final String algorithm, final int bitlength) {
    System.out.println();
    System.out.println("---");
    System.out.println("Using " + algorithm + " with the domain parameters:");

    boolean success;

    try {
      // generate an EC key pair
      final KeyPair kp = generateKeyPair(bitlength);

      // obtain an ECDSA instance
      final Signature ecdsa = Signature.getInstance(algorithm, ECCelerate.getInstance());
      // initialize the signature instance for the signing operation
      ecdsa.initSign(kp.getPrivate());
      // feed the data into the signature instance
      ecdsa.update(TO_BE_SIGNED.getBytes());

      // obtain the signature
      final byte[] signature = ecdsa.sign();

      System.out.println();
      System.out.println("Signature of '" + TO_BE_SIGNED + ": " + Util.toString(signature));

      // initialize the signature instance for verification
      ecdsa.initVerify(kp.getPublic());
      // feed the data into the signature instance
      ecdsa.update(TO_BE_SIGNED.getBytes());

      // verify the signature
      success = ecdsa.verify(signature);
    } catch (final Exception e) {
      System.out.println("Error occurred: " + e.getMessage());

      return false;
    }

    // print the result
    System.out.println();
    System.out.println("Signature verification: " + (success ? "ok" : "failed"));

    return success;
  }

  @Override
  public boolean run() {
    boolean overallSuccess = true;

    System.out.println("IAIK ECDSA Demo");
    System.out.println();

    // use curve K-163
    overallSuccess &= signAndVerify("SHAwithECDSA", 163);
    // use curve P-192
    overallSuccess &= signAndVerify("SHAwithECDSA", 192);
    // use curve P-224
    overallSuccess &= signAndVerify("SHA224withECDSA", 224);
    // use curve K-233
    overallSuccess &= signAndVerify("SHA224withECDSA", 233);
    // use curve P-256
    overallSuccess &= signAndVerify("SHA256withECDSA", 256);
    // use curve K-283
    overallSuccess &= signAndVerify("SHA256withECDSA", 283);
    // use curve P-384
    overallSuccess &= signAndVerify("SHA384withECDSA", 384);
    // use curve K-409
    overallSuccess &= signAndVerify("SHA384withECDSA", 409);
    // use curve P-521
    overallSuccess &= signAndVerify("SHA512withECDSA", 521);
    // use curve K-571
    overallSuccess &= signAndVerify("SHA512withECDSA", 571);

    System.out.println();
    System.out.println("---");
    System.out.println(overallSuccess ? "All operations were SUCCESSFUL"
        : "At least one operation FAILED");

    return overallSuccess;
  }

  /**
   * The main method.
   *
   * @param args
   *          will be ignored
   */
  public static void main(final String[] args) {
    // add the providers
    init();

    ECDSADemo demo = null;

    // create a demo instance
    try {
      demo = new ECDSADemo();

      // wait for user input
      iaik.utils.Util.waitKey();

      // return exit status 0, if no error occurred or 1 otherwise
      final int result = demo.run() ? 0 : 1;
      // wait for user input
      iaik.utils.Util.waitKey();

      System.exit(result);
    } catch (final NoSuchAlgorithmException e) {
      System.out
          .println("The IAIK ECCelerate provider can only be used in combination with IAIK provider versions higher than 4.0");

      System.exit(2);
    }
  }
}
