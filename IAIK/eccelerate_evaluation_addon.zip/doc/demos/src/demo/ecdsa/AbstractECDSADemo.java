// Copyright (C) 2002 IAIK
// http://jce.iaik.at
//
// Copyright (C) 2003 - 2016 Stiftung Secure Information and
//                           Communication Technologies SIC
// http://www.sic.st
//
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
// 1. Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
// 2. Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
// OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
// OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
// SUCH DAMAGE.

package demo.ecdsa;

import iaik.security.ec.common.ECStandardizedParameterFactory;
import iaik.security.ec.provider.ECCelerate;
import iaik.security.provider.IAIK;

import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.AlgorithmParameterSpec;

/**
 * This class serves as base class for all protocol demos involving ECDSA.
 *
 * @author Christian Hanser
 */
abstract class AbstractECDSADemo {

  public final SecureRandom random_;

  /**
   * Creates a new instance.
   *
   * @throws NoSuchAlgorithmException
   *           in case an earlier version of the IAIK provider (prior to 4.0) is
   *           used
   */
  public AbstractECDSADemo() throws NoSuchAlgorithmException {
    random_ = SecureRandom.getInstance("SHA512PRNG-SP80090", IAIK.getInstance());
  }

  /**
   * Registers the IAIK as well as the IAIK ECCelerate? provider.
   */
  static void init() {
    IAIK.addAsProvider();
    ECCelerate.insertProviderAt(2);
  }

  /**
   * Generates a key pair for a curve with a certain name_
   *
   * @param bitlength
   *          the bitlength of the domain parameters to be used
   * @return the generated key pair
   */
  protected KeyPair generateKeyPair(final int bitlength) {
    try {
      final AlgorithmParameterSpec params = ECStandardizedParameterFactory
          .getParametersByBitLength(bitlength);

      System.out.println();
      System.out.println("Using the following EC domain parameters: ");
      System.out.println(params);
      System.out.println();

      final KeyPairGenerator kpg = KeyPairGenerator.getInstance("EC", ECCelerate.getInstance());
      kpg.initialize(params, random_);

      return kpg.generateKeyPair();
    } catch (final Exception e) {
      // should not occur
      e.printStackTrace();

      return null;
    }
  }
}
